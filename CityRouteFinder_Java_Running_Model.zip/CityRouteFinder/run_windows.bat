@echo off
title City Route Finder
cd /d "%~dp0"
where javac >nul 2>nul
if errorlevel 1 (
  echo Java JDK was not found. Install JDK 8 or later and add it to PATH.
  pause
  exit /b 1
)
javac CityRouteFinder.java
if errorlevel 1 (
  echo Compilation failed.
  pause
  exit /b 1
)
java CityRouteFinder
pause
