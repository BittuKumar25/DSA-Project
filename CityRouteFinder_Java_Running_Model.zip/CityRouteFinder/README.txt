# City Route Finder – Java Running Model

A desktop GUI demonstration of the City Route Finder project described in the interim report.

## Features
- Professional Java Swing user interface
- City road network represented as an undirected weighted graph
- `HashMap` / Map-based adjacency storage
- Dijkstra shortest-distance route calculation using a `PriorityQueue`
- BFS traversal using a Queue
- DFS traversal using a Stack
- Add or update a road and immediately recalculate routes
- Visual city network with highlighted shortest route
- Route distance and step-by-step path display

## Demo data from the report
Locations:
- Railway Station
- Gandhi Maidan
- Airport
- Bus Stand
- Patna University

Roads:
- Railway Station – Gandhi Maidan: 5 km
- Railway Station – Bus Stand: 3 km
- Gandhi Maidan – Airport: 6 km
- Bus Stand – Gandhi Maidan: 2 km
- Bus Stand – Patna University: 4 km
- Patna University – Airport: 3 km

Expected shortest route:
Railway Station → Bus Stand → Patna University → Airport = 10 km

## Requirements
- JDK 8 or later
- Windows, Linux or macOS

## Run on Windows
1. Extract the ZIP file.
2. Open the extracted `CityRouteFinder` folder.
3. Open Command Prompt in that folder.
4. Compile:
   `javac CityRouteFinder.java`
5. Run:
   `java CityRouteFinder`

You can also double-click `run_windows.bat` if Java JDK is installed and `java` / `javac` are available in PATH.

## Run on Linux / macOS
From the project folder:
```bash
javac CityRouteFinder.java
java CityRouteFinder
```

## Demonstration steps
1. Select `Railway Station` as source.
2. Select `Airport` as destination.
3. Click `FIND SHORTEST ROUTE`.
4. Show the highlighted route and 10 km total distance.
5. Click `BFS Traversal` and `DFS Traversal` to demonstrate graph traversal.
6. Click `+ Add Road` to add or update a road, then calculate again.

## Important academic note
The report's main shortest-distance feature is implemented with Dijkstra. BFS and DFS are included as graph traversal demonstrations. The graph is a sample city network, not a live GPS or traffic-connected map. All road distances are demo data from the report.
