import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

/**
 * City Route Finder
 * A Java Swing demonstration project using Graph, HashMap, BFS, DFS and Dijkstra.
 * Compile: javac CityRouteFinder.java
 * Run:     java CityRouteFinder
 */
public class CityRouteFinder extends JFrame {
    private final CityGraph graph = new CityGraph();
    private final JComboBox<String> sourceBox = new JComboBox<>();
    private final JComboBox<String> destinationBox = new JComboBox<>();
    private final JLabel distanceValue = new JLabel("-- km");
    private final JLabel statusValue = new JLabel("Ready to find a route");
    private final JTextArea detailsArea = new JTextArea();
    private final GraphPanel graphPanel = new GraphPanel();
    private final Color navy = new Color(20, 34, 58);
    private final Color blue = new Color(42, 104, 190);
    private final Color background = new Color(245, 247, 251);

    public CityRouteFinder() {
        super("City Route Finder | Smart Navigation System");
        seedData();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1080, 700));
        setSize(1240, 800);
        setLocationRelativeTo(null);
        getContentPane().setBackground(background);
        setLayout(new BorderLayout(0, 0));
        add(buildHeader(), BorderLayout.NORTH);
        add(buildMainContent(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);
        refreshLocations();
        detailsArea.setText("Welcome to City Route Finder.\\n\\n"
                + "Select a source and destination, then click FIND SHORTEST ROUTE.\\n"
                + "The demo network uses the locations and distances from the project report.");
    }

    private void seedData() {
        graph.addLocation("Railway Station");
        graph.addLocation("Gandhi Maidan");
        graph.addLocation("Airport");
        graph.addLocation("Bus Stand");
        graph.addLocation("Patna University");

        graph.addRoad("Railway Station", "Gandhi Maidan", 5);
        graph.addRoad("Railway Station", "Bus Stand", 3);
        graph.addRoad("Gandhi Maidan", "Airport", 6);
        graph.addRoad("Bus Stand", "Gandhi Maidan", 2);
        graph.addRoad("Bus Stand", "Patna University", 4);
        graph.addRoad("Patna University", "Airport", 3);
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(navy);
        header.setBorder(new EmptyBorder(22, 30, 22, 30));

        JPanel titlePanel = new JPanel();
        titlePanel.setOpaque(false);
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("CITY ROUTE FINDER");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD, 27));
        JLabel subtitle = new JLabel("SMART CITY NAVIGATION  •  SHORTEST PATH USING GRAPH ALGORITHMS");
        subtitle.setForeground(new Color(190, 207, 230));
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 12));
        subtitle.setBorder(new EmptyBorder(6, 1, 0, 0));
        titlePanel.add(title);
        titlePanel.add(subtitle);

        JLabel tag = new JLabel("JAVA  |  DSA PROJECT");
        tag.setForeground(Color.WHITE);
        tag.setFont(new Font("SansSerif", Font.BOLD, 12));
        tag.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(95, 130, 175), 1, true),
                new EmptyBorder(9, 14, 9, 14)));
        header.add(titlePanel, BorderLayout.WEST);
        header.add(tag, BorderLayout.EAST);
        return header;
    }

    private JPanel buildMainContent() {
        JPanel main = new JPanel(new BorderLayout(18, 18));
        main.setBackground(background);
        main.setBorder(new EmptyBorder(20, 22, 18, 22));

        JPanel left = new JPanel(new BorderLayout(0, 14));
        left.setBackground(background);
        left.setPreferredSize(new Dimension(330, 500));
        left.add(buildControlsCard(), BorderLayout.NORTH);
        left.add(buildDetailsCard(), BorderLayout.CENTER);

        JPanel right = new JPanel(new BorderLayout(0, 10));
        right.setBackground(background);
        right.add(buildMapHeading(), BorderLayout.NORTH);
        graphPanel.setPreferredSize(new Dimension(650, 500));
        right.add(graphPanel, BorderLayout.CENTER);

        main.add(left, BorderLayout.WEST);
        main.add(right, BorderLayout.CENTER);
        return main;
    }

    private JPanel card(String titleText) {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(226, 231, 239)),
                new EmptyBorder(16, 16, 16, 16)));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        JLabel title = new JLabel(titleText);
        title.setFont(new Font("SansSerif", Font.BOLD, 15));
        title.setForeground(navy);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createVerticalStrut(14));
        return panel;
    }

    private JPanel buildControlsCard() {
        JPanel panel = card("Plan your journey");
        panel.add(fieldLabel("STARTING LOCATION"));
        styleCombo(sourceBox);
        panel.add(sourceBox);
        panel.add(Box.createVerticalStrut(12));
        panel.add(fieldLabel("DESTINATION"));
        styleCombo(destinationBox);
        panel.add(destinationBox);
        panel.add(Box.createVerticalStrut(16));

        JButton find = primaryButton("FIND SHORTEST ROUTE");
        find.addActionListener(e -> findShortestRoute());
        panel.add(find);
        panel.add(Box.createVerticalStrut(9));

        JPanel row = new JPanel(new GridLayout(1, 2, 8, 0));
        row.setOpaque(false);
        JButton bfs = secondaryButton("BFS Traversal");
        JButton dfs = secondaryButton("DFS Traversal");
        bfs.addActionListener(e -> runTraversal(true));
        dfs.addActionListener(e -> runTraversal(false));
        row.add(bfs);
        row.add(dfs);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(row);
        panel.add(Box.createVerticalStrut(9));

        JButton addRoad = secondaryButton("+ Add Road");
        addRoad.addActionListener(e -> addRoadDialog());
        panel.add(addRoad);

        panel.add(Box.createVerticalStrut(12));
        JLabel note = new JLabel("<html><div style='width:260px'>Dijkstra finds the minimum-distance path. "
                + "BFS and DFS demonstrate graph traversal.</div></html>");
        note.setForeground(new Color(105, 116, 132));
        note.setFont(new Font("SansSerif", Font.PLAIN, 11));
        note.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(note);
        return panel;
    }

    private JPanel buildDetailsCard() {
        JPanel panel = card("Route information");
        JPanel metric = new JPanel(new BorderLayout());
        metric.setBackground(new Color(237, 244, 255));
        metric.setBorder(new EmptyBorder(12, 12, 12, 12));
        JLabel caption = new JLabel("TOTAL DISTANCE");
        caption.setForeground(new Color(75, 99, 132));
        caption.setFont(new Font("SansSerif", Font.BOLD, 10));
        distanceValue.setForeground(blue);
        distanceValue.setFont(new Font("SansSerif", Font.BOLD, 27));
        metric.add(caption, BorderLayout.NORTH);
        metric.add(distanceValue, BorderLayout.CENTER);
        metric.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(metric);
        panel.add(Box.createVerticalStrut(10));

        statusValue.setFont(new Font("SansSerif", Font.BOLD, 11));
        statusValue.setForeground(new Color(36, 133, 91));
        statusValue.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(statusValue);
        panel.add(Box.createVerticalStrut(8));

        detailsArea.setEditable(false);
        detailsArea.setLineWrap(true);
        detailsArea.setWrapStyleWord(true);
        detailsArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        detailsArea.setForeground(new Color(55, 66, 82));
        detailsArea.setBackground(new Color(250, 251, 253));
        detailsArea.setBorder(new EmptyBorder(10, 10, 10, 10));
        JScrollPane scroll = new JScrollPane(detailsArea);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(232, 236, 242)));
        scroll.setPreferredSize(new Dimension(280, 190));
        scroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(scroll);
        return panel;
    }

    private JPanel buildMapHeading() {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        JLabel heading = new JLabel("City network map");
        heading.setFont(new Font("SansSerif", Font.BOLD, 17));
        heading.setForeground(navy);
        JLabel legend = new JLabel("● Location     ━ Road     ━ Shortest route");
        legend.setFont(new Font("SansSerif", Font.PLAIN, 11));
        legend.setForeground(new Color(105, 116, 132));
        p.add(heading, BorderLayout.WEST);
        p.add(legend, BorderLayout.EAST);
        return p;
    }

    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(new Color(235, 239, 245));
        footer.setBorder(new EmptyBorder(9, 22, 9, 22));
        JLabel left = new JLabel("PROJECT: CITY ROUTE FINDER  |  STUDENT: BITTU KUMAR  |  ERP: 11805");
        left.setFont(new Font("SansSerif", Font.PLAIN, 10));
        left.setForeground(new Color(83, 96, 115));
        JLabel right = new JLabel("DSA • JAVA • GRAPH");
        right.setFont(new Font("SansSerif", Font.BOLD, 10));
        right.setForeground(new Color(83, 96, 115));
        footer.add(left, BorderLayout.WEST);
        footer.add(right, BorderLayout.EAST);
        return footer;
    }

    private JLabel fieldLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("SansSerif", Font.BOLD, 10));
        label.setForeground(new Color(91, 105, 125));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private void styleCombo(JComboBox<String> combo) {
        combo.setFont(new Font("SansSerif", Font.PLAIN, 13));
        combo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        combo.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    private JButton primaryButton(String text) {
        JButton b = new JButton(text);
        b.setFont(new Font("SansSerif", Font.BOLD, 11));
        b.setForeground(Color.WHITE);
        b.setBackground(blue);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(12, 12, 12, 12));
        b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        return b;
    }

    private JButton secondaryButton(String text) {
        JButton b = new JButton(text);
        b.setFont(new Font("SansSerif", Font.BOLD, 11));
        b.setForeground(navy);
        b.setBackground(new Color(241, 245, 250));
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 227, 237)),
                new EmptyBorder(8, 8, 8, 8)));
        b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        return b;
    }

    private void refreshLocations() {
        String oldSource = (String) sourceBox.getSelectedItem();
        String oldDestination = (String) destinationBox.getSelectedItem();
        sourceBox.removeAllItems();
        destinationBox.removeAllItems();
        for (String name : graph.getLocations()) {
            sourceBox.addItem(name);
            destinationBox.addItem(name);
        }
        if (oldSource != null) sourceBox.setSelectedItem(oldSource);
        if (oldDestination != null) destinationBox.setSelectedItem(oldDestination);
        if (destinationBox.getItemCount() > 1 && destinationBox.getSelectedIndex() == 0) {
            destinationBox.setSelectedIndex(2);
        }
    }

    private void findShortestRoute() {
        String source = (String) sourceBox.getSelectedItem();
        String destination = (String) destinationBox.getSelectedItem();
        if (source == null || destination == null) return;
        if (source.equals(destination)) {
            JOptionPane.showMessageDialog(this, "Please select two different locations.");
            return;
        }

        PathResult result = graph.dijkstra(source, destination);
        if (result.path.isEmpty()) {
            distanceValue.setText("-- km");
            statusValue.setText("No route found");
            statusValue.setForeground(new Color(190, 65, 65));
            detailsArea.setText("No route exists between the selected locations.");
            graphPanel.setHighlightedPath(Collections.<String>emptyList());
            return;
        }

        distanceValue.setText(result.distance + " km");
        statusValue.setText("ROUTE FOUND SUCCESSFULLY");
        statusValue.setForeground(new Color(36, 133, 91));
        StringBuilder sb = new StringBuilder();
        sb.append("SHORTEST ROUTE\\n");
        sb.append("────────────────────────\\n");
        for (int i = 0; i < result.path.size(); i++) {
            sb.append(i + 1).append(". ").append(result.path.get(i));
            if (i < result.path.size() - 1) {
                int w = graph.getRoadDistance(result.path.get(i), result.path.get(i + 1));
                sb.append("\\n      ↓  ").append(w).append(" km\\n");
            }
        }
        sb.append("\\n────────────────────────\\n");
        sb.append("TOTAL DISTANCE: ").append(result.distance).append(" km\\n");
        sb.append("LOCATIONS IN ROUTE: ").append(result.path.size());
        detailsArea.setText(sb.toString());
        graphPanel.setHighlightedPath(result.path);
    }

    private void runTraversal(boolean breadthFirst) {
        String source = (String) sourceBox.getSelectedItem();
        if (source == null) return;
        List<String> order = breadthFirst ? graph.bfs(source) : graph.dfs(source);
        distanceValue.setText("-- km");
        statusValue.setText(breadthFirst ? "BFS TRAVERSAL COMPLETE" : "DFS TRAVERSAL COMPLETE");
        statusValue.setForeground(blue);
        detailsArea.setText((breadthFirst ? "BREADTH FIRST SEARCH (BFS)" : "DEPTH FIRST SEARCH (DFS)")
                + "\\n────────────────────────\\nStarting location: " + source
                + "\\n\\nTraversal order:\\n" + String.join("  →  ", order)
                + "\\n\\n" + (breadthFirst ? "Queue" : "Stack / Recursion")
                + " is used as the traversal mechanism.");
        graphPanel.setHighlightedPath(Collections.<String>emptyList());
    }

    private void addRoadDialog() {
        List<String> names = graph.getLocations();
        JComboBox<String> from = new JComboBox<>(names.toArray(new String[0]));
        JComboBox<String> to = new JComboBox<>(names.toArray(new String[0]));
        JTextField distance = new JTextField("5");
        JPanel form = new JPanel(new GridLayout(0, 1, 4, 4));
        form.add(new JLabel("From location")); form.add(from);
        form.add(new JLabel("To location")); form.add(to);
        form.add(new JLabel("Distance in km")); form.add(distance);
        int choice = JOptionPane.showConfirmDialog(this, form, "Add a road",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (choice == JOptionPane.OK_OPTION) {
            try {
                String a = (String) from.getSelectedItem();
                String b = (String) to.getSelectedItem();
                int d = Integer.parseInt(distance.getText().trim());
                if (a.equals(b) || d <= 0) throw new IllegalArgumentException();
                graph.addRoad(a, b, d);
                graphPanel.repaint();
                detailsArea.setText("Road added successfully:\\n" + a + " ↔ " + b
                        + "\\nDistance: " + d + " km\\n\\nNow find a route to see the updated shortest path.");
                statusValue.setText("NETWORK UPDATED");
                statusValue.setForeground(blue);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Enter two different locations and a positive whole-number distance.",
                        "Invalid road", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    private class GraphPanel extends JPanel {
        private List<String> highlighted = new ArrayList<>();
        private final Map<String, Point> points = new LinkedHashMap<>();

        GraphPanel() {
            setBackground(Color.WHITE);
            setBorder(BorderFactory.createLineBorder(new Color(226, 231, 239)));
            points.put("Railway Station", new Point(105, 250));
            points.put("Gandhi Maidan", new Point(315, 115));
            points.put("Airport", new Point(545, 250));
            points.put("Bus Stand", new Point(315, 390));
            points.put("Patna University", new Point(545, 445));
        }

        void setHighlightedPath(List<String> path) {
            highlighted = new ArrayList<>(path);
            repaint();
        }

        private Point pointFor(String name, int index, int total) {
            if (points.containsKey(name)) return points.get(name);
            int w = Math.max(getWidth(), 650), h = Math.max(getHeight(), 500);
            double angle = 2 * Math.PI * index / Math.max(total, 1);
            return new Point((int)(w/2 + 210*Math.cos(angle)), (int)(h/2 + 190*Math.sin(angle)));
        }

        @Override protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            List<String> names = graph.getLocations();
            Map<String, Point> coords = new LinkedHashMap<>();
            for (int i = 0; i < names.size(); i++) coords.put(names.get(i), pointFor(names.get(i), i, names.size()));

            // Subtle map grid
            g.setColor(new Color(244, 247, 251));
            for (int x = 25; x < getWidth(); x += 35) g.drawLine(x, 15, x, getHeight()-15);
            for (int y = 15; y < getHeight(); y += 35) g.drawLine(15, y, getWidth()-15, y);

            // Roads
            Set<String> drawn = new HashSet<>();
            for (String from : names) {
                for (Edge edge : graph.neighbours(from)) {
                    String key = from.compareTo(edge.to) < 0 ? from + "|" + edge.to : edge.to + "|" + from;
                    if (!drawn.add(key)) continue;
                    Point a = coords.get(from), b = coords.get(edge.to);
                    boolean active = isHighlightedEdge(from, edge.to);
                    g.setStroke(new BasicStroke(active ? 5f : 2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    g.setColor(active ? new Color(30, 160, 110) : new Color(184, 195, 209));
                    g.drawLine(a.x, a.y, b.x, b.y);
                    int mx = (a.x + b.x)/2, my = (a.y + b.y)/2;
                    g.setColor(new Color(255,255,255));
                    g.fillRoundRect(mx-20, my-12, 40, 23, 10, 10);
                    g.setColor(new Color(76, 91, 112));
                    g.setFont(new Font("SansSerif", Font.BOLD, 11));
                    g.drawString(edge.weight + " km", mx-16, my+4);
                }
            }

            // Nodes
            for (String name : names) {
                Point p = coords.get(name);
                boolean onPath = highlighted.contains(name);
                int r = 22;
                g.setColor(new Color(25, 45, 75, 25));
                g.fillOval(p.x-r+2, p.y-r+3, r*2, r*2);
                g.setColor(onPath ? new Color(30, 160, 110) : blue);
                g.fillOval(p.x-r, p.y-r, r*2, r*2);
                g.setColor(Color.WHITE);
                g.setStroke(new BasicStroke(2f));
                g.drawOval(p.x-r, p.y-r, r*2, r*2);
                g.setFont(new Font("SansSerif", Font.BOLD, 10));
                g.setColor(navy);
                String label = name;
                FontMetrics fm = g.getFontMetrics();
                int lx = p.x - fm.stringWidth(label)/2;
                int ly = p.y + 40;
                g.drawString(label, lx, ly);
            }
            g.dispose();
        }

        private boolean isHighlightedEdge(String a, String b) {
            for (int i = 0; i < highlighted.size()-1; i++) {
                if ((highlighted.get(i).equals(a) && highlighted.get(i+1).equals(b))
                        || (highlighted.get(i).equals(b) && highlighted.get(i+1).equals(a))) return true;
            }
            return false;
        }
    }

    // ---------------- Graph and algorithms ----------------

    private static class Edge {
        String to;
        int weight;
        Edge(String to, int weight) { this.to = to; this.weight = weight; }
    }

    private static class NodeDistance implements Comparable<NodeDistance> {
        String node;
        int distance;
        NodeDistance(String node, int distance) { this.node = node; this.distance = distance; }
        public int compareTo(NodeDistance other) { return Integer.compare(distance, other.distance); }
    }

    private static class PathResult {
        List<String> path;
        int distance;
        PathResult(List<String> path, int distance) { this.path = path; this.distance = distance; }
    }

    private static class CityGraph {
        private final Map<String, List<Edge>> adjacency = new LinkedHashMap<>();

        void addLocation(String name) {
            adjacency.putIfAbsent(name, new ArrayList<Edge>());
        }

        void addRoad(String a, String b, int distance) {
            addLocation(a);
            addLocation(b);
            removeExistingEdge(a, b);
            removeExistingEdge(b, a);
            adjacency.get(a).add(new Edge(b, distance));
            adjacency.get(b).add(new Edge(a, distance));
        }

        private void removeExistingEdge(String from, String to) {
            List<Edge> edges = adjacency.get(from);
            if (edges != null) edges.removeIf(e -> e.to.equals(to));
        }

        List<String> getLocations() {
            return new ArrayList<>(adjacency.keySet());
        }

        List<Edge> neighbours(String name) {
            return adjacency.containsKey(name) ? adjacency.get(name) : Collections.<Edge>emptyList();
        }

        int getRoadDistance(String a, String b) {
            for (Edge e : neighbours(a)) if (e.to.equals(b)) return e.weight;
            return -1;
        }

        PathResult dijkstra(String source, String destination) {
            Map<String, Integer> dist = new HashMap<>();
            Map<String, String> previous = new HashMap<>();
            for (String node : adjacency.keySet()) dist.put(node, Integer.MAX_VALUE);
            dist.put(source, 0);

            PriorityQueue<NodeDistance> pq = new PriorityQueue<>();
            pq.add(new NodeDistance(source, 0));

            while (!pq.isEmpty()) {
                NodeDistance current = pq.poll();
                if (current.distance != dist.get(current.node)) continue;
                if (current.node.equals(destination)) break;

                for (Edge edge : neighbours(current.node)) {
                    if (current.distance != Integer.MAX_VALUE
                            && current.distance + edge.weight < dist.get(edge.to)) {
                        int newDistance = current.distance + edge.weight;
                        dist.put(edge.to, newDistance);
                        previous.put(edge.to, current.node);
                        pq.add(new NodeDistance(edge.to, newDistance));
                    }
                }
            }

            if (dist.get(destination) == Integer.MAX_VALUE)
                return new PathResult(Collections.<String>emptyList(), -1);

            LinkedList<String> path = new LinkedList<>();
            String at = destination;
            while (at != null) {
                path.addFirst(at);
                at = previous.get(at);
            }
            return new PathResult(path, dist.get(destination));
        }

        List<String> bfs(String start) {
            List<String> order = new ArrayList<>();
            Set<String> visited = new LinkedHashSet<>();
            Queue<String> queue = new LinkedList<>();
            visited.add(start);
            queue.add(start);
            while (!queue.isEmpty()) {
                String current = queue.poll();
                order.add(current);
                for (Edge edge : neighbours(current)) {
                    if (visited.add(edge.to)) queue.add(edge.to);
                }
            }
            return order;
        }

        List<String> dfs(String start) {
            List<String> order = new ArrayList<>();
            Set<String> visited = new LinkedHashSet<>();
            Stack<String> stack = new Stack<>();
            stack.push(start);
            while (!stack.isEmpty()) {
                String current = stack.pop();
                if (visited.contains(current)) continue;
                visited.add(current);
                order.add(current);
                List<Edge> edges = new ArrayList<>(neighbours(current));
                // Reverse push order to keep traversal stable and readable.
                for (int i = edges.size()-1; i >= 0; i--) {
                    if (!visited.contains(edges.get(i).to)) stack.push(edges.get(i).to);
                }
            }
            return order;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) {}
            new CityRouteFinder().setVisible(true);
        });
    }
}